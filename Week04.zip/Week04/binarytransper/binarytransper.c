#include <stdio.h>
#define SIZE 10 
int main(void) {

	int binary[SIZE] = { 0 };
	int decimal = 8;

}